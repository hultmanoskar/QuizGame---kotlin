package com.ogge.quizgame20

object Var {
    const val USER_NAME: String = "user_name"
    const val Right_answer: String = "right_answer"
    const val Total_questions: String = "total_questions"

}